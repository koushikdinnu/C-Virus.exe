import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InviteThirdPartyMerchantComponent } from './invite-third-party-merchant.component';

describe('InviteThirdPartyMerchantComponent', () => {
  let component: InviteThirdPartyMerchantComponent;
  let fixture: ComponentFixture<InviteThirdPartyMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InviteThirdPartyMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteThirdPartyMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
