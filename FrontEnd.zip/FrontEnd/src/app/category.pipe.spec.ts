import { CategoryPipe } from './category.pipe';

describe('CategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new CategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
