import { Component, OnInit } from '@angular/core';
import { Email } from '../email';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-inbox-email',
  templateUrl: './inbox-email.component.html',
  styleUrls: ['./inbox-email.component.css']
})
export class InboxEmailComponent implements OnInit {
  array: Email[];
  constructor(private adminService:AdminServiceService) { }

  ngOnInit() {
    this.adminService.getInbox().subscribe(data=>this.responseData(data));
  }

  responseData(data){
    this.array=data;
  }
}
