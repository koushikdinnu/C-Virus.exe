import { Component, OnInit } from '@angular/core';


import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  orderId="";
  merchantId="";
  category="";
  businessList = new OrderedItem();
  constructor(private businessService: AdminServiceService) { }

  

  ngOnInit() {
    this.businessService.display().subscribe( (businessli) => 
    {
      this.businessList = (businessli);
      console.log(this.businessList);
      // console.log("Testing")
    }
  )
    
  }

}
