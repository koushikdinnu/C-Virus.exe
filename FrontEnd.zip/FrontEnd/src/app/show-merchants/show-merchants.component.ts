import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-show-merchants',
  templateUrl: './show-merchants.component.html',
  styleUrls: ['./show-merchants.component.css']
})
export class ShowMerchantsComponent implements OnInit {

  merchant:Merchant[];

  constructor( private httpClientService:AdminServiceService) { }

  ngOnInit() {
    this.httpClientService.showMerchants().subscribe(
      data =>{this.merchant = data;}
     );
  }

}
