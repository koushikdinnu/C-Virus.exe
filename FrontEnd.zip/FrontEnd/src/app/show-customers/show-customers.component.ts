import { Component, OnInit } from '@angular/core';

import { AdminServiceService } from '../admin-service.service';
import { Customer } from '../Customer';


@Component({
  selector: 'app-show-customers',
  templateUrl: './show-customers.component.html',
  styleUrls: ['./show-customers.component.css']
})


export class ShowCustomersComponent implements OnInit {
customer:Customer[];
  constructor( private httpClientService:AdminServiceService) { }

  ngOnInit() {
    this.httpClientService.showCustomers().subscribe(
      data =>{this.customer = data;}
     );
  }

}
